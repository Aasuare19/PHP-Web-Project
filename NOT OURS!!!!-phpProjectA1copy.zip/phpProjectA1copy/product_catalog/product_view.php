<html>
<!-- the head section -->
<head>
    <title>A and J Online Store</title>
    <link rel="stylesheet" type="text/css" href="/workspace/%/main.css">
</head>

<!-- the body section -->
<body>
<header>
    <a href="/workspace/%/index.php"><img src="../images/icon_logo.png" alt="A and J Online Store"></a>
    <a class="icon_cart" href="/CIS_4260_PHP_Project/cart/index.ph"><img src="../images/icon_cart.png" alt="Shopping Cart"></a>
</header>
<main>
    <aside>
        <h1>Categories</h1>
        <nav>
        <ul>
            <!-- display links for all categories -->
            <?php foreach($categories as $category) : ?>
            <li>
                <a href="?category_id=<?php echo $category->getID();?>&page=1">
                    <?php echo $category->getName(); ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
        </nav>
    </aside>
    <section>
        <h1><?php echo $product->getName(); ?></h1>
        <div id="left_column">
            <p>
                <img src="<?php echo $product->getImagePath(); ?>"
                    alt="<?php echo $product->getImageAltText(); ?>">
            </p>
        </div>
        <div id="right_column">
            <p><b>List Price:</b> $<?php echo $product->getPriceFormatted(); ?></p>
            <p><b>Description:</b> <?php echo $product->getProductDescription(); ?></p>

        <form action="<?php echo '../cart' ?>" method="get">
            <input type="submit" value="View in Cart" />
        </form>
        </div>
    </section>
</main>
<?php include '../view/footer.php'; ?>