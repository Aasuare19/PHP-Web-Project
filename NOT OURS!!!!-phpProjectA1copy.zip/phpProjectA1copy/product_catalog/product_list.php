<html>
<!-- the head section -->
<head>
    <title>A and J Online Store</title>
    <link rel="stylesheet" type="text/css" href="/workspace/%/main.css">
</head>

<!-- the body section -->
<body>
<header>
    <a href="/workspace/%/index.php"><img src="../images/icon_logo.png" alt="A and J Online Store"></a>
    <a class="icon_cart" href="/CIS_4260_PHP_Project/cart/index.php"><img src="../images/icon_cart.png" alt="Shopping Cart"></a>
</header>
<main>
    <h1>Product List</h1>
    <aside>
        <!-- display a list of categories -->
        <h2>Categories</h2>
        <nav>
        <ul>
        <?php foreach ($categories as $category) : ?>
            <li>
            <a href="?category_id=<?php echo $category->getID();?>&page=1">
                <?php echo $category->getName(); ?>
            </a>
            </li>
        <?php endforeach; ?>
        </ul>
        </nav>
    </aside>
    <section>
        <!-- display a table of products -->
        <h2><?php echo $current_category->getName(); ?></h2>
        <table>
            <tr>
                <th>Name</th>
                <th class="right">Price</th>
                
            </tr>
            <?php foreach ($products as $product) : ?>
            <tr>
                <td><a href="?action=view_product&amp;product_id= <?php echo $product->getID();?>">
                    <?php echo $product->getName(); ?> 
                    </a>
                </td>
                <td class="right"><?php echo $product->getPriceFormatted(); ?></td>
            </tr>
            <?php endforeach; ?>
        </table> 
<?php 
    // Assign total number of items based on category)_id
    $db = Database::getDB();
    $category_id_num = filter_input (INPUT_GET, 'category_id');
    
    //if statement to display pagination based on category
    if ($category_id_num == 1){
        $total = 17;
        // Number of items to list per page
        $limit = 8;
        // Number of pges needed ceil() rounds float up 
        $pages = ceil($total / $limit);

        // Get the current page, or set to default (1)
        $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
            'options' => array(
                'default'   => 1,
                'min_range' => 1,
            ),
        )));
        // The "back" link
        $prev_link = ($page > 1) ? '<a href="?page=1" title="First page">&laquo;</a> <a href="?page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : 
            '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';
        // The "next" link
        $next_link = ($page < $pages) ? '<a href="?page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="?page=' . $pages . '" title="Last page">&raquo;</a>' : 
            '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';
    }else if ($category_id_num == 2){
        $total = 9;
        $limit = 8;
        $pages = ceil($total / $limit);
        $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
            'options' => array(
                'default'   => 1,
                'min_range' => 1,
            ),
        )));
        // prev_link and next_link are specific to this section
        $prev_link = ($page > 1) ? '<a href="?category_id=2&page=1" title="First page">&laquo;</a> <a href="?category_id=2&page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : 
            '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';
        $next_link = ($page < $pages) ? '<a href="?category_id=2&page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="?category_id=2&page=' . $pages . '" title="Last page">&raquo;</a>' : 
            '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';
    }else if ($category_id_num == 3){
        $total = 9;
        $limit = 8;
        $pages = ceil($total / $limit);
        $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
            'options' => array(
                'default'   => 1,
                'min_range' => 1,
            ),
        )));
        // prev_link and next_link are specific to this section
        $prev_link = ($page > 1) ? '<a href="?category_id=3&page=1" title="First page">&laquo;</a> <a href="?category_id=3&page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : 
            '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';
        $next_link = ($page < $pages) ? '<a href="?category_id=3&page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="?category_id=3&page=' . $pages . '" title="Last page">&raquo;</a>' : 
            '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';
    }else {
        $total = 17;
        $limit = 8;
        $pages = ceil($total / $limit);
        $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
            'options' => array(
                'default'   => 1,
                'min_range' => 1,
            ),
        )));
        $prev_link = ($page > 1) ? '<a href="?page=1" title="First page">&laquo;</a> <a href="?page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : 
            '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';
        $next_link = ($page < $pages) ? '<a href="?page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="?page=' . $pages . '" title="Last page">&raquo;</a>' : 
            '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';
    }
    
    // Calculate the offset for the query
    $offset = ($page - 1)  * $limit;
    
    // Variables to display
    $start = $offset + 1;
    $end = min(($offset + $limit), $total);
    
    // Display the paging information
    echo '<div id="paging"><p>', $prev_link, ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start, '-', $end, ' of ', $total, ' results ', $next_link, ' </p></div>';
?>
    </section>
</main>
<?php include '../view/footer.php'; ?>