<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>A and J Online Store</title>
    <link rel="stylesheet" type="text/css" href="./main.css">
    <link rel="stylesheet" type="text/css" href="../main.css">
</head>

<!-- the body section -->
<body>
<header>
    <a href="/workspace/%/index.php"><img src="images/icon_logo.png" alt="A and J Online Store"></a>
    <a class="icon_cart" href="/workspace/%/cart/index.php"><img src="images/icon_cart.png" alt="Shopping Cart"></a>
</header>
