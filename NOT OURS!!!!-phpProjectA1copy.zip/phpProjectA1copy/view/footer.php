<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> A and J Online Store, Inc.
    </p>
</footer>
</body>
</html>