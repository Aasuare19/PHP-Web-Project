<?php
class ProductDB {
    
    public static function getProductsByCategory($category_id) {
        $db = Database::getDB();
        $category = CategoryDB::getCategory($category_id);
        $pageNum = filter_input(INPUT_GET, 'page');
        if ($pageNum == 1) {
            $query = 'SELECT * FROM products
                  WHERE products.categoryID = :category_id
                  ORDER BY productID
                  LIMIT 8';
        }else if ($pageNum==2) {
            $query = 'SELECT * FROM products
                  WHERE products.categoryID = :category_id
                  ORDER BY productID
                  LIMIT 8,8';
        }else if ($pageNum == 3) {
            $query = 'SELECT * FROM products
                  WHERE products.categoryID = :category_id
                  ORDER BY productID
                  LIMIT 16,8';
        }else {
            $query = 'SELECT * FROM products
                  WHERE products.categoryID = :category_id
                  ORDER BY productID';
        }
        $statement = $db->prepare($query);
        $statement->bindValue(":category_id", $category_id);
        $statement->execute();
        $rows = $statement->fetchAll();
        $statement->closeCursor(); 
        foreach ($rows as $row) {
            $product = new Product($category,
                                   $row['productCode'],
                                   $row['productName'],
                                   $row['listPrice'],
                                   $row['productDescription']);
            $product->setId($row['productID']);
            $products[] = $product;
        }
        return $products;
    }

    
    public static function getProduct($product_id) {
        $db = Database::getDB();
        $query = 'SELECT * FROM products
                  WHERE productID = :product_id';
        $statement = $db->prepare($query);
        $statement->bindValue(":product_id", $product_id);
        $statement->execute();
        $row = $statement->fetch();
        $statement->closeCursor();
    
        $category = CategoryDB::getCategory($row['categoryID']);
        $product = new Product($category,
                               $row['productCode'],
                               $row['productName'],
                               $row['listPrice'],
                               $row['productDescription']);
        $product->setID($row['productID']);
        return $product;
    }
    
    
}


