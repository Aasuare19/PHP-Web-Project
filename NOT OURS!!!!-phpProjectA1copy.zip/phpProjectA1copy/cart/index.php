<?php
// Start session management
session_start();

// Create a cart array if needed
if (empty($_SESSION['cart13'])) { $_SESSION['cart13'] = array(); }

// Create a table of products
$products = array();
$products['s1'] = array('name' => 'Nike Flyknit Trainer', 'cost' => '50.99');
$products['s2'] = array('name' => 'Kobe 5\'s', 'cost' => '125.55');
$products['s3'] = array('name' => 'Kobe 6 Grinches', 'cost' => '200.00');
$products['s4'] = array('name' => 'Kobe 7 Sharks', 'cost' => '160.99');
$products['s5'] = array('name' => 'Kobe 8 Sparks', 'cost' => '250.00');
$products['s6'] = array('name' => 'Kobe 9 Elite What The', 'cost' => '200.00');
$products['s7'] = array('name' => 'Kobe 10', 'cost' => '250.00');
$products['s8'] = array('name' => 'Nike Flyknit Trainers Kanye West', 'cost' => '150.00');
$products['s9'] = array('name' => 'Paul George', 'cost' => '120.00');
$products['s10'] = array('name' => 'Kyrie Irving', 'cost' => '120.00');
$products['s11'] = array('name' => 'Adidas Ultra Boost 4.0 core black', 'cost' => '180.00');
$products['s12'] = array('name' => 'Adidas Ultra Boost 4.0 Pure Whites', 'cost' => '150.00');
$products['s13'] = array('name' => 'Chuck Taylor II', 'cost' => '80.00');
$products['s14'] = array('name' => 'Vans Old Skool', 'cost' => '65.00');
$products['s15'] = array('name' => 'Retro Jordan 1s', 'cost' => '200.00');
$products['s16'] = array('name' => 'Flyknit Racers', 'cost' => '150.00');
$products['s17'] = array('name' => 'Nike Lunarepic 2', 'cost' => '130.00');
$products['c1'] = array('name' => 'Supreme Box Logo Tee', 'cost' => '60.00');
$products['c2'] = array('name' => 'Kith Slash logo tee', 'cost' => '50.00');
$products['c3'] = array('name' => 'Champion Heritage logo Tee', 'cost' => '25.00');
$products['c4'] = array('name' => 'Kith Champion Double Logo tee', 'cost' => '120.00');
$products['c5'] = array('name' => 'Hidden Characters Tee', 'cost' => '45.00');
$products['c6'] = array('name' => 'Guess A$AP logo tee', 'cost' => '100.00');
$products['c7'] = array('name' => 'Primitive DragonBall Z tee', 'cost' => '30.00');
$products['c8'] = array('name' => 'Obey tee', 'cost' => '20.00');
$products['c9'] = array('name' => 'Uniqlo Tee', 'cost' => '15.00');
$products['a1'] = array('name' => 'Supreme Hat', 'cost' => '85.00');
$products['a2'] = array('name' => 'Kith Hat', 'cost' => '30.00');
$products['a3'] = array('name' => 'The Hundreds Hat', 'cost' => '25.00');
$products['a4'] = array('name' => 'Daniel Wellington Watch', 'cost' => '100.00');
$products['a5'] = array('name' => 'Nikon Watch', 'cost' => '150.00');
$products['a6'] = array('name' => 'Apple Watch', 'cost' => '300.00');
$products['a7'] = array('name' => 'Apple Air Pods', 'cost' => '250.00');
$products['a8'] = array('name' => 'Lightning Cable', 'cost' => '20.00');
$products['a9'] = array('name' => 'Apple Case', 'cost' => '15.00');

// Include cart functions
require_once('cart.php');

// Get the sort key
$sort_key = filter_input(INPUT_POST, 'sortkey');
if ($sort_key === NULL) { $sort_key = 'name'; }

// Get the action to perform
$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action === NULL) {
        $action = 'show_add_item';
    }
}

// Add or update cart as needed
switch($action) {
    case 'add':
        $key = filter_input(INPUT_POST, 'productkey');
        $quantity  = filter_input(INPUT_POST, 'itemqty');
        cart\add_item($key, $quantity);
        include('cart_view.php');
        break;
    case 'update':
        $new_qty_list = filter_input(INPUT_POST, 'newqty', 
                FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
        foreach($new_qty_list as $key => $qty) {
            if ($_SESSION['cart13'][$key]['qty'] != $qty) {
                cart\update_item($key, $qty);
            }
        }
        cart\sort($sort_key);
        include('cart_view.php');
        break;
    case 'show_cart':
        cart\sort($sort_key);
        include('cart_view.php');
        break;
    case 'show_add_item':
        include('add_item_view.php');
        break;
    case 'empty_cart':
        unset($_SESSION['cart13']);
        include('cart_view.php');
        break;
}
?>