<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>A and J Online Store</title>
    <link rel="stylesheet" type="text/css" href="/workspace/%/main.css">
</head>

<!-- the body section -->
<body>
<header>
    <a href="/workspace/%/index.php"><img src="../images/icon_logo.png" alt="A and J Online Store"></a>
    <a class="icon_cart" href="/workspace/%/cart/index.php"><img src="../images/icon_cart.png" alt="Shopping Cart"></a>
</header>
    <main>
        <h1>Add Item</h1>
        <form action="." method="post">
            <input type="hidden" name="action" value="add">

            <label>Name:</label>
            <select name="productkey">
            <?php foreach($products as $key => $product) :
                $cost = number_format($product['cost'], 2);
                $name = $product['name'];
                $item = $name . ' ($' . $cost . ')';
            ?>
                <option value="<?php echo $key; ?>">
                    <?php echo $item; ?>
                </option>
            <?php endforeach; ?>
            </select><br>

            <label>Quantity:</label>
            <select name="itemqty">
            <?php for($i = 1; $i <= 10; $i++) : ?>
                <option value="<?php echo $i; ?>">
                    <?php echo $i; ?>
                </option>
            <?php endfor; ?>
            </select><br>

            <label>&nbsp;</label>
            <input type="submit" value="Add Item">
        </form>
        <p><a href=".?action=show_cart">View Cart</a></p>    
    </main>
</body>
</html>