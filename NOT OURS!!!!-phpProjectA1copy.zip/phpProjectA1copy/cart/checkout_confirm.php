<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>A and J Online Store</title>
    <link rel="stylesheet" type="text/css" href="/workspace/%/main.css">
</head>

<!-- the body section -->
<body>
<header>
    <a href="\phpProjectA1\index.php"><img src="../images/icon_logo.png" alt="A and J Online Store"></a>
    <a class="icon_cart" href="\phpProjectA1\cart\index.php"><img src="../images/icon_cart.png" alt="Shopping Cart"></a>
</header>
<main>
    <h1>Confirm Order</h1>
    <table id="cart">
        <tr id="cart_header">
            <th class="left" >Item</th>
            <th class="right">Price</th>
            <th class="right">Quantity</th>
            <th class="right">Total</th>
        </tr>
        
        <!-- code to display the result goes here O.o -->
        
</table>
    <img src="../images/coming_soon.png" alt="Coming Soon Placeholder">
</main>
<?php include '../view/footer.php'; ?>