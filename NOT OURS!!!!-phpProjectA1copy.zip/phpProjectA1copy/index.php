<?php include 'view/header.php'; ?>
<body>
    <main>
        <div class="homePageDiv">
            <h1>Menu</h1>
                <ul>
                    <li>
                        <!--href is product catalog with pagination page 1 default address-->
                        <a href="/workspace/%/product_catalog/?page=1">Product Catalog</a>
                    </li>
                </ul>
            <h1>Featured products</h1>
            <p>Check out this month's hottest selections!</p>
        </div>
        <div class="box">            
            <h1>Obey Tee</h1>
            <img src="./images/c8.jpg" alt="Obey Tee">
            <p><strong>Description:</strong> Obey t-shirt 100% cotton.</p>
            <form action="<?php echo './cart' ?>" method="get">
            <input type="submit" value="View in Cart" />
            </form>
        </div>
        <div class="box">            
            <h1>Apple Air Pods</h1>
            <img src="./images/a7.jpg" alt="Obey Tee">
            <p><strong>Description:</strong> Wireless ear buds compatible with all iPhones..</p>
            <form action="<?php echo './cart' ?>" method="get">
            <input type="submit" value="View in Cart" />
            </form>
        </div>
        <div class="box">            
            <h1>Nikon Watch</h1>
            <img src="./images/a5.jpg" alt="Obey Tee">
            <p><strong>Description:</strong> Black watch with black strap.</p>
            <form action="<?php echo './cart' ?>" method="get">
            <input type="submit" value="View in Cart" />
            </form>
        </div>
    </main>
</body>
<?php include 'view/footer.php'; ?>