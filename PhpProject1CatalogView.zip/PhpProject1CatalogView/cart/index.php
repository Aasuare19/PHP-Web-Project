<?php
// Start session management with a persistent cookie
$lifetime = 60 * 60 * 24 * 14;    // 2 weeks in seconds

// set session cookie parameters
session_set_cookie_params($lifetime, '/');

// Start new or resume existing session
session_start();   

// Create an array named cart12 if needed, and 
// the cart12 is an element in the default session array, $_SESSION
if (empty($_SESSION['cart12'])) 
    $_SESSION['cart12'] = array();


$products = array();
$products['DGTWNM80'] = array('name' => 'Nike Flyknit Trainer', 'cost' => '50.99');
$products['DGTWNM80'] = array('name' => 'Dogtown Skateboards Scott Oster M80 Transparent Bl...', 'cost' => '119.99');
$products['GBSTEVO'] = array('name' => 'Globe Bantam ST Evo Hawaiian Mint Cup Cruiser', 'cost' => '99.99');
$products['GBG1WC'] = array('name' => 'Globe G1 Alight Off White Cruiser', 'cost' => '84.99');
$products['DGTWNOG'] = array('name' => 'Dogtown Skateboards OG Rider Bull Dog White / Red', 'cost' => '119.99');
$products['GLBPINW'] = array('name' => 'Globe Pinner Classic White / Mustard Longboard', 'cost' => '149.95');
$products['ENJPANP'] = array('name' => 'Enjoi Skateboards Faded Panda Pink', 'cost' => '79.99');
$products['ELMNTBM'] = array('name' => 'Element Skateboards Bam Margera Heartagram Black', 'cost' => '64.99');
$products['ALMSTFF'] = array('name' => 'Almost Skateboards Fat Font', 'cost' => '79.99');
$products['DRKSTRCS'] = array('name' => 'Darkstar Skateboards Cosmic Silver', 'cost' => '69.95');
$products['DRKSTRSS'] = array('name' => 'Darkstar Skateboards Sure Shot Matte Ice Blue Micr...', 'cost' => '64.99');
$products['DGKTRIP'] = array('name' => 'DGK Skateboards Trippy', 'cost' => '89.99');
$products['ELMNTSYL'] = array('name' => 'Element Skateboards Sylvan', 'cost' => '89.99');
$products['AWSVIDL'] = array('name' => 'Alien Workshop Videolog White / Rainbow', 'cost' => '89.95');
$products['PNYCOLBC'] = array('name' => 'Penny Skateboards Cobalt Classic 22" Cruiser', 'cost' => '79.99');
$products['PNYRDCM'] = array('name' => 'Penny Skateboards Red Comet 27" Cruiser', 'cost' => '89.99');
$products['PWPTASKS'] = array('name' => 'Powell Peralta Skull & Sword Mini', 'cost' => '79.99');
$products['SCT9H95'] = array('name' => 'Sector 9 Howl Ninety Five Cruiser', 'cost' => '139.96');
$products['ROSSTMPS'] = array('name' => 'Rossignol Templar Snowboard', 'cost' => '399.95');
$products['BATBLWS'] = array('name' => 'Bataleon Blow Snowboard', 'cost' => '379.95');
$products['NVRSMRART'] = array('name' => 'Never Summer Artist Edition Snowtrooper X Snowboar...', 'cost' => '519.99');
$products['RSSSLGWL'] = array('name' => 'Rossignol XV Sashimi LG White Label Snowboard', 'cost' => '599.95');
$products['LBTCBC2'] = array('name' => 'Lib Tech Cold Brew C2 Snowboard', 'cost' => '459.95');
$products['GNUAIRC3'] = array('name' => 'GNU x Airblaster SPAM C3 Snowboard', 'cost' => '539.96');
$products['BRTNFTRR'] = array('name' => 'Burton Family Tree Speed Date Retro Snowboard', 'cost' => '649.95');
$products['RMEWINTS'] = array('name' => 'Rome Winterland Snowboard', 'cost' => '539.99');
$products['NTRWDCS'] = array('name' => 'Nitro Woodcarver Snowboard', 'cost' => '509.96');
$products['CTCHSRFL'] = array('name' => 'Catch Surf Log 6\'0" Surfboard', 'cost' => '324.95');
$products['LBTLSTRD'] = array('name' => 'Lib Tech x Lost Round Nose Fish Redux Surfboard', 'cost' => '739.99');
$products['SFTCHHND'] = array('name' => 'Softech Handshaped SB 6\'6\'\' Surfboard', 'cost' => '279.95');
$products['CTCHSRFRNF'] = array('name' => 'Catch Surf Odysea x Lost RNF 5\'5" Surfboard', 'cost' => '324.99');
$products['MDRNBBSB'] = array('name' => 'Modern Blackbird PU 7\'6" Longboard', 'cost' => '449.95');
$products['SFTCHDSS'] = array('name' => 'Softech DSS TC Comp 6\'6\'\' Surfboard', 'cost' => '344.95');
$products['CRARHPU'] = array('name' => 'Creative Army Huevo PU 6\'10" Funboard', 'cost' => '694.99');
$products['CTSRFB48'] = array('name' => 'Catch Surf Beater Original 48" Twin Fin Board', 'cost' => '179.95');
$products['ALMNDLJ'] = array('name' => 'Almond Surfboards 9\'6" Lumberjack Surfboard', 'cost' => '1339.95');




// Hard-code two dimensional array for products, not use database
//$products = array();
//$products['MMS-1754'] = 
//              array('name' => 'Flute', 'cost' => '149.50');
//$products['MMS-6289'] = 
//              array('name' => 'Trumpet', 'cost' => '199.50');
//$products['MMS-3408'] = 
//              array('name' => 'Clarinet', 'cost' => '299.50');

// Include cart functions from cart.php
require_once('cart.php');

// Get the action to perform
if (isset($_POST['action'])) {
    $action = $_POST['action'];
} else if (isset($_GET['action'])) {
    $action = $_GET['action'];
} else {
    $action = 'show_add_item';
}

// Add or update cart as needed
switch($action) {
case 'add':
    // add_item function is defined in cart.php
add_item($_POST['product_id'], $_POST['itemqty']);
        include('cart_view.php');
        break;
    case 'update':
        $new_qty_list = $_POST['newqty'];
        foreach($new_qty_list as $key => $qty) {
            if ($_SESSION['cart12'][$key]['qty'] != $qty) {
               // update_item() is defined in cart.php 
               update_item($key, $qty);
            }
        }
        include('cart_view.php');
        break;

    case 'show_cart':
        include('cart_view.php');
        break;
    case 'show_add_item':
        include('add_item_view.php');
        break;
    case 'empty_cart':
        unset($_SESSION["cart12"]);
        include('cart_view.php');
        break;
}
?>
