<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>Xtreme Ultra Sports</title>
    <link rel="stylesheet" type="text/css"
          href="../main.css">
</head>

<!-- the body section -->
<body>
<header><h1>Xtreme Ultra Sports 🏄 🏂</h1>
<form action="<?php echo '../cart/index.php' ?>" method="post">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="product_id"
                       value="<?php echo $code; ?>">
                <input type="submit" value="View Cart">
            </form>
</header>
    
</div>
