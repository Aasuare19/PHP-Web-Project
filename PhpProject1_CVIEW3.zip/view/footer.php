<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> Xtreme Ultra Sports, Inc.
    </p>
</footer>
</body>
</html>