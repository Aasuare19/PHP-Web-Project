<?php
function get_products_by_category($category_id, $page_number) {
    global $db;
    $query = 'SELECT * FROM products
              WHERE products.categoryID = :category_id
              ORDER BY productID
              LIMIT :lower_limit, :upper_limit';
    $statement = $db->prepare($query);
    
    if ($page_number == 1){
        $lower_limit = 0;
        $upper_limit = 8;    
        $statement->bindValue(':lower_limit', $lower_limit, PDO::PARAM_INT);
        $statement->bindValue(':upper_limit', $upper_limit, PDO::PARAM_INT);
    } else if ($page_number == 2) {
        $lower_limit = 8;
        $upper_limit = 16;
        $statement->bindValue(':lower_limit', $lower_limit, PDO::PARAM_INT);
        $statement->bindValue(':upper_limit', $upper_limit, PDO::PARAM_INT);
    } else {
        $lower_limit = 16;
        $upper_limit = 17;
        $statement->bindValue(':lower_limit', $lower_limit, PDO::PARAM_INT);
        $statement->bindValue(':upper_limit', $upper_limit, PDO::PARAM_INT);
    }
    //$statement->bindValue(':limit', 12);
    
    $statement->bindValue(':category_id', $category_id);
    $statement->execute();
    $products = $statement->fetchAll();
    $statement->closeCursor();
    return $products;
}

function get_product($product_id) {
    global $db;
    $query = 'SELECT * FROM products
              WHERE productID = :product_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':product_id', $product_id);
    $statement->execute();
    $product = $statement->fetch();
    $statement->closeCursor();
    return $product;
}

function delete_product($product_id) {
    global $db;
    $query = 'DELETE FROM products
              WHERE productID = :product_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':product_id', $product_id);
    $statement->execute();
    $statement->closeCursor();
}

function add_product($category_id, $code, $name, $price) {
    global $db;
    $query = 'INSERT INTO products
                 (categoryID, productCode, productName, listPrice)
              VALUES
                 (:category_id, :code, :name, :price)';
    $statement = $db->prepare($query);
    $statement->bindValue(':category_id', $category_id);
    $statement->bindValue(':code', $code);
    $statement->bindValue(':name', $name);
    $statement->bindValue(':price', $price);
    $statement->execute();
    $statement->closeCursor();
}
?>