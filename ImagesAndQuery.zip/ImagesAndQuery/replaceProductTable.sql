USE music;

Drop TABLE Product;

CREATE TABLE Product(
    ProductID INT NOT NULL AUTO_INCREMENT,
    ProductCode VARCHAR(10) NOT NULL DEFAULT '',
    ProductDescription VARCHAR(100) NOT NULL DEFAULT '',
    ProductPrice DECIMAL(7,2) NOT NULL DEFAULT '0.00',
  
    PRIMARY KEY (ProductID)
);

INSERT INTO Product VALUES 
(1, 'DGTWNM80', 'Dogtown Skateboards Scott Oster M80 Transparent Blue Cruiser', 119.99),
(2, 'GBSTEVO', 'Globe Bantam ST Evo Hawaiian Mint Cup Cruiser ', 99.99),
(3, 'GBG1WC', 'Globe G1 Alight Off White Cruiser', 84.99),
(4, 'DGTWNOG', 'Dogtown Skateboards OG Rider Bull Dog White / Red', 119.99),
(5, 'GLBPINW', 'Globe Pinner Classic White / Mustard Longboard', 149.95),
(6, 'ENJPANP', 'Enjoi Skateboards Faded Panda Pink', 79.99),
(7, 'ELMNTBM', 'Element Skateboards Bam Margera Heartagram Black', 64.99),
(8, 'ALMSTFF', 'Almost Skateboards Fat Font', 79.99),
(9, 'DRKSTRCS', 'Darkstar Skateboards Cosmic Silver', 69.95),
(10, 'DRKSTRSS', 'Darkstar Skateboards Sure Shot Matte Ice Blue Micro', 64.99),
(11, 'DGKTRIP', 'DGK Skateboards Trippy', 89.99),
(12, 'ELMNTSYL', 'Element Skateboards Sylvan', 89.99),
(13, 'AWSVIDL', 'Alien Workshop Videolog White / Rainbow', 89.95),
(14, 'PNYCOLBC', 'Penny Skateboards Cobalt Classic 22\" Cruiser', 79.99),
(15, 'PNYRDCM', 'Penny Skateboards Red Comet 27\" Cruiser', 89.99),
(16, 'PWPTASKS', 'Powell Peralta Skull & Sword Mini', 79.99),
(17, 'SCT9H95', 'Sector 9 Howl Ninety Five Cruiser', 139.96),
(18, 'ROSSTMPS', 'Rossignol Templar Snowboard', 399.95),
(19, 'BATBLWS', 'Bataleon Blow Snowboard', 379.95),
(20, 'NVRSMRART', 'Never Summer Artist Edition Snowtrooper X Snowboard', 519.99),
(21, 'RSSSLGWL', 'Rossignol XV Sashimi LG White Label Snowboard', 599.95),
(22, 'LBTCBC2', 'Lib Tech Cold Brew C2 Snowboard', 459.95),
(23, 'GNUAIRC3', 'GNU x Airblaster SPAM C3 Snowboard', 539.96),
(24, 'BRTNFTRR', 'Burton Family Tree Speed Date Retro Snowboard', 649.95),
(25, 'RMEWINTS', 'Rome Winterland Snowboard', 539.99),
(26, 'NTRWDCS', 'Nitro Woodcarver Snowboard', 509.96),
(27, 'CTCHSRFL', 'Catch Surf Log 6\'0\" Surfboard', 324.95),
(28, 'LBTLSTRD', 'Lib Tech x Lost Round Nose Fish Redux Surfboard', 739.99),
(29, 'SFTCHHND', 'Softech Handshaped SB 6\'6\'\' Surfboard', 279.95),
(30, 'CTCHSRFRNF', 'Catch Surf Odysea x Lost RNF 5\'5\" Surfboard', 324.99),
(31, 'MDRNBBSB', 'Modern Blackbird PU 7\'6\" Longboard', 449.95),
(32, 'SFTCHDSS', 'Softech DSS TC Comp 6\'6\'\' Surfboard', 344.95),
(33, 'CRARHPU', 'Creative Army Huevo PU 6\'10\" Funboard', 694.99),
(34, 'CTSRFB48', 'Catch Surf Beater Original 48\" Twin Fin Board', 179.95),
(35, 'ALMNDLJ', 'Almond Surfboards 9\'6\" Lumberjack Surfboard', 1339.95),
(36, 'CHNLIEK', 'CHANNEL ISLANDS EVEN KEEL SURFBOARD', 895.99),
(37, 'BLCKRMB', 'BLACK ROSE MFG. BENEDICT SURFBOARD', 1045.94),
(38, 'WLDNMMS', 'WALDEN MAGIC MODEL SURFBOARD X2\'', 820.99),
(39, 'CTHSFOS', 'CATCH SURF ODYSEA SPECIAL 5\'4\' THRUSTER SOFT SURFBOARD', 284.99),
(40, 'LRPERSB', 'LOST RAD RIPPER SURFBOARD', 770.99),
(41, 'TRQPGSB', 'TORQ PG-R SURFBOARD - TEC', 510.99),
(42, 'KCHLMMS', 'KECHELE MINI MALIBU SURFBOARD', 639.95),
(43, 'SHRPSSP', 'SHARP EYE SOLE SOFTOP PC SURFBOARD', 499.95),
(44, 'GNUFBHSAS', 'GNU FB Head Space Asym C3 Snowboard 2020', 459.99),
(45, 'GNUMC3S', 'GNU Mullair C3 Snowboard 2020', 599.99),
(46, 'JONEHSW', 'Jones Hovercraft Snowboard - Womens', 499.97),
(47, 'LTJLPDC2', 'Lib Tech JL Phoenix Dagmar C2 Snowboard - Blem 2019', 439.96),
(48, 'EPAEARSB', 'Endeavor Patrol Early Release Splitboard 2019', 490.00),
(49, 'LTJLXLMC3', 'Lib Tech Jamie Lynn x Lost Mayhem C3 Snowboard - Blem 2019', 439.96),
(50, 'RSBSBBW', 'Roxy Sugar Banana Snowboard - Blem - Women', 349.95),
(51, 'ROSALSB', 'Rossignol Alias Snowboard - Kids', 187.46),
(52, 'ROSSWBSB', 'Rossignol Sawblade Snowboard 2019', 244.96);




