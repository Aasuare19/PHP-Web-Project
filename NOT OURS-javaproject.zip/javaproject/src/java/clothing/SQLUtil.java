package clothing;

import java.sql.*;

public class SQLUtil {

    public static String getHtmlTable(ResultSet results)
            throws SQLException {
        
        StringBuilder htmlTable = new StringBuilder();
        ResultSetMetaData metaData = results.getMetaData();
        int columnCount = metaData.getColumnCount();

        htmlTable.append("<table id=\"myTable\">");

        // add header row
        htmlTable.append("<tr>");
        for (int i = 1; i <= columnCount; i++) {
            switch (i) {
                case 4:
                    htmlTable.append("<th>");
                    htmlTable.append("<a onclick=\"sortTableByItem()\" href=\"#\">Item</a>");
                    htmlTable.append("</th>");
                    break;
                case 5:
                    htmlTable.append("<th>");
                    htmlTable.append("Item Description");
                    htmlTable.append("</th>");
                    break;
                case 6:
                    htmlTable.append("<th>");
                    htmlTable.append("<a onclick=\"sortTableByPrice()\" href=\"#\">Unit Price(US Dollars)</a>");
                    htmlTable.append("</th>");
                    break;
                default:
                    break;
            }
        }
        htmlTable.append("</tr>");

        // add all other rows
        while (results.next()) {
            htmlTable.append("<tr>");
            for (int i = 1; i <= columnCount; i++) {
                switch (i) {
                    case 4:
                        htmlTable.append("<td>");
                        htmlTable.append("<a href=\"#\">").append(results.getString(i)).append("</a>");
                        htmlTable.append("</td>");
                        break;
                    case 5:
                        htmlTable.append("<td>");
                        htmlTable.append(results.getString(i));
                        htmlTable.append("</td>");
                        break;
                    case 6:
                        htmlTable.append("<td>");
                        String priceString = results.getString(i);
                        double price = Double.parseDouble(priceString);
                        htmlTable.append(price);
                        htmlTable.append("</td>");
                        break;
                    default:
                        break;
                }
            }
            htmlTable.append("</tr>");
        }
        htmlTable.append("</table>");
        return htmlTable.toString();
    }
}